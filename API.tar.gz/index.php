<?php 
header("location: ../");
?>