<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	// die($tahun);
	
	$query		= "
					SELECT X.id_satker,X.nama_satker,Y.jumlah_inovasi,Y.nama_inovasi,Y.persentase 
					FROM penilaian_satker.master_satker AS X 
					LEFT JOIN 
						(
							SELECT A.id_satker, NAMA_SATKER(A.id_satker) AS nama_satker,
							COUNT(A.id_satker) AS jumlah_inovasi, 
							GROUP_CONCAT(CONCAT(A.nama_inovasi) ORDER BY A.nama_inovasi ASC SEPARATOR '<br>') AS nama_inovasi,
							(IF(COUNT(A.id_satker)>10,10,COUNT(A.id_satker)) * 10) AS persentase
							FROM tb_inovasi AS A 
							WHERE ($tahun - A.tahun_aktif <= 3)
							GROUP BY A.id_satker
						) AS Y ON X.id_satker_dipa01=Y.id_satker
					WHERE X.aktif='1' AND X.tingkat_satker='PA'
					
					"; 
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$record['nama_inovasi'] =  preg_replace('/[^A-Za-z0-9\ ]/','',$record['nama_inovasi']); // buat karakter aneh di buang, banyak banget di db komar
					// $record['nama_inovasi'] =  "xxx";
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>