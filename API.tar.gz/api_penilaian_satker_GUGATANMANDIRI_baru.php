<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	//REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	$th_next=$tahun+1;
	
	$id_satker	=DEC($_POST['id_satker']);
	if($id_satker==0) {$s_sip = ""; $s_gm="";} 
		else {$s_sip = "WHERE yy.id=$id_satker"; 
				$s_gm = "AND id=$id_satker";}
	
	
	
	// $tahun=2023;
	// $triwulan=2;
	// $th_next=$tahun+1;
	
	if($triwulan==1) { $waktu="'$tahun-01-01' AND '$tahun-03-31'"; 
	$waktu2=" AND waktu_kirim<='$tahun-04-07'";}
	elseif($triwulan==2){ $waktu="'$tahun-04-01' AND '$tahun-06-30'"; 
	$waktu2=" AND waktu_kirim<='$tahun-07-07'";}
	elseif($triwulan==3){$waktu="'$tahun-07-01' AND '$tahun-09-30'"; 
	$waktu2=" AND waktu_kirim<='$tahun-10-07'"; }
	elseif($triwulan==4){$waktu="'$tahun-10-01' AND '$tahun-12-31'"; 
	$waktu2=" AND waktu_kirim<='$th_next-01-07'";}
	else{$waktu="";}
	
	
	 $server		= "192.168.99.157";
	$username	= "saroyon";
	$password	= "b1sm1ll4h"; 

	/*$server		= "192.168.99.157";
	$username	= "kinsatker";
	$password	= "aQuaRon88";*/

	$database	= "gugatan_mandiri";
	$kon_gm = mysqli_connect("$server","$username","$password","$database");
	
	$query		= "
	SELECT 
	
	A.nama,A.id AS id_satker_sipp,
	(CASE WHEN B.cg IS NULL THEN 0 ELSE B.cg END) AS cg,
	(CASE WHEN B.ct IS NULL THEN 0 ELSE B.ct END) AS ct,
	(CASE WHEN B.dk IS NULL THEN 0 ELSE B.dk END) AS dk,
	(CASE WHEN B.total IS NULL THEN 0 ELSE B.total END) AS total
	
	FROM pengadilan_negeri AS A LEFT JOIN 
	(SELECT id_satker_sipp,SUM(CASE WHEN jns=347 THEN 1 ELSE 0 END) AS cg,
	SUM(CASE WHEN jns=346 THEN 1 ELSE 0 END) AS ct,
	SUM(CASE WHEN jns=362 THEN 1 ELSE 0 END) AS dk,
	COUNT(jns) AS total
	FROM `data_simpan_v3` 
	WHERE tgl_input BETWEEN $waktu
	GROUP BY id_satker_sipp) AS B ON A.id=B.id_satker_sipp
	
	WHERE aktif='Y' AND jenis_pengadilan=4 $s_gm;
	";
	//echo $id_satker.'-----------' 346,347,362;
	//echo $query.'<br/>---------<br/>';
	//exit();
	$mysql_query= mysqli_query($kon_gm, $query);
	
	while($record = mysqli_fetch_assoc ($mysql_query))
	{
		$hasil[] = $record; 
	}
	$jadi=array();
	foreach($hasil as $key=>$value) {
		$idsat=$value['id_satker_sipp'];
		$jadi[$idsat]['id_satker']=$value['id_satker_sipp'];
		$jadi[$idsat]['nama_satker']=$value['nama'];
		$jadi[$idsat]['jumlah_cg']=$value['cg'];
		$jadi[$idsat]['jumlah_ct']=$value['ct'];
		$jadi[$idsat]['jumlah_dk']=$value['dk'];
		$jadi[$idsat]['jumlah_gm']=$value['total'];
	}
	
	$server2	= "192.168.99.161";
	$username2	= "rekap";
	$password2	= "badilagjaya";
	$database2	= "pusat_data";
	$kon_sip = mysqli_connect("$server2","$username2","$password2","$database2");
	
	$print2		= "
	SELECT  yy.id AS id_satker,xx.jml
	FROM pengadilan_negeri AS yy LEFT JOIN
	(SELECT id_satker,SUM(CASE WHEN id_jenis_perkara IN (346,347) THEN 1 ELSE 0 END) AS jml
	FROM data_perkara 
	WHERE tgl_daftar BETWEEN $waktu
	GROUP BY id_satker) AS xx ON yy.id=xx.id_satker $s_sip
		
	";
	//echo $id_satker.'-----------';
	//echo $print2;
	//exit();
	$exe_print= mysqli_query($kon_sip, $print2);
	
	while($isi = mysqli_fetch_assoc ($exe_print))
	{
		$hs_sip[] = $isi; 
	}
	
	foreach($hs_sip as $key=>$value) {
		$idsat=$value['id_satker'];
		$jadi[$idsat]['jumlah_sipp']=$value['jml'];
		if($value['jml']>0) {$jms=$value['jml'];}else{$jms=-1;}
		
		$persen=$jadi[$idsat]['jumlah_gm']/$jms*100;
		$persen=number_format($persen,0,'.',',');
		if($persen>100){$jadi[$idsat]['persentase']=100;}
		elseif($persen>=1 and $persen<=20) {$jadi[$idsat]['persentase']=50;}
		elseif($persen>=21 and $persen<=40) {$jadi[$idsat]['persentase']=75;}
		elseif($persen>=41) {$jadi[$idsat]['persentase']=100;}
		else{$jadi[$idsat]['persentase']=0;}
	}
	
	if(!mysqli_num_rows($mysql_query)) 
	{ 
		echo "Load Data Api Gagal... !!!";
	}
	else
	{
		
		foreach($jadi as $key=>$value) {
			$jk[]=$value;
		}
		echo JSON_ENCODE($jk);
	}
	
?>