<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	// $tahun		= '2022';
	// $triwulan	= '2';
			
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "HAVING id_satker='$id_satker'";
	
	$query		= "
                    SELECT XX.*, (XX.tingkat_nasional + XX.tingkat_provinsi + XX.tingkat_kabupaten ) AS persentase
                    FROM (
                        SELECT A.id_satker, A.`nama_satker`,
                        X.nas AS juara_nasional, X.prof AS juara_provinsi, X.kab AS juara_kabupaten,
                        CASE
                            WHEN X.nas > 2 THEN '50'
                            WHEN X.nas > 0 AND X.nas <= 2 THEN '30'
                            ELSE '0' END 
                        AS tingkat_nasional,
                        CASE
                            WHEN X.prof > 2 THEN '30'
                            WHEN X.prof > 0 AND X.prof <= 2 THEN '20'
                            ELSE '0' END 
                        AS tingkat_provinsi,
                        CASE
                            WHEN X.kab > 2 THEN '20'
                            WHEN X.kab > 0 AND X.kab <= 2 THEN '15'
                            ELSE '0' END 
                        AS tingkat_kabupaten
                        FROM master_satker AS A
                        LEFT JOIN (
                            SELECT B.id_satker,
                            SUM(CASE WHEN B.kategori_id >= 3 THEN 1 ELSE 0 END) AS nas,
                            SUM(CASE WHEN B.kategori_id = 2 THEN 1 ELSE 0 END) AS prof,
                            SUM(CASE WHEN B.kategori_id = 1 THEN 1 ELSE 0 END) AS kab
                            FROM tb_juara AS B
                            LEFT JOIN tb_juara_verifikasi AS C ON B.`id_juara` = C.`id_juara`
                            WHERE B.tahun_juara >= YEAR(CURDATE())-3  AND C.`validasi_nilai` = '1'
                            GROUP BY B.id_satker
                        ) AS X ON A.`id_satker_dipa01` = X.id_satker
                        WHERE A.tingkat_satker IN('PA') AND A.aktif = TRUE
                    ) AS XX
					$SATKER
					;
				 "; 			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>