<?php
//LOCAL
// $server		= "localhost";
// $username	= "root";
// $password	= "1q2w3e4r";
// $database	= "ditbinganis";
//LOCAL

//ONLINE
$server		= "localhost";
$username	= "root";
// $password	= "b@d1l4gj4y4";
$password	= "b@d1l4gj4y4";
$database	= "ekinerja";
//ONLINE

$koneksi = mysqli_connect("$server","$username","$password","$database");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database $database gagal : " . mysqli_connect_error();
}
?>