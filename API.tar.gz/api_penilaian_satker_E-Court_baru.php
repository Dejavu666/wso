<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	$server2	= "192.168.111.134";
			$username2	= "ecourtbadilag";
			$password2	= "3c0U12t@badilag#";
			$database2	= "ecourt";
			$kon_ec = mysqli_connect("$server2","$username2","$password2","$database2");
			
			$tahun		= DEC($_POST['tahun']);
			$triwulan	= DEC($_POST['triwulan']);
			$id_satker	= DEC($_POST['id_satker']);
			
			
			// $tahun=2023;
			// $triwulan=2;
			// $id_satker=0;
			// $th_next=$tahun+1;

			if($id_satker==0) {$s_sip = ""; $s_ec="";} 
			else {$s_sip = "WHERE yy.id=$id_satker"; 
			$s_ec = "AND zz.id='$id_satker'";}
			
			if($triwulan==1) { $waktu="'$tahun-01-01' AND '$tahun-03-31'"; 
			$waktu2=" AND waktu_kirim<='$tahun-04-07'";}
			elseif($triwulan==2){ $waktu="'$tahun-04-01' AND '$tahun-06-30'"; 
			$waktu2=" AND waktu_kirim<='$tahun-07-07'";}
			elseif($triwulan==3){$waktu="'$tahun-07-01' AND '$tahun-09-30'"; 
			$waktu2=" AND waktu_kirim<='$tahun-10-07'"; }
			elseif($triwulan==4){$waktu="'$tahun-10-01' AND '$tahun-12-31'"; 
			$waktu2=" AND waktu_kirim<='$th_next-01-07'";}
			else{$waktu="";}
			
			/*
			$query		= "
			SELECT zz.id,nama,ecourt,litigasi
			FROM
			pengadilan_negeri AS zz LEFT JOIN
			(SELECT satker_id,COUNT(satker_id) AS ecourt
			FROM efiling a
			LEFT JOIN pengadilan_negeri b
			ON a.satker_id=b.id
			WHERE tgl_pendaftaran_perkara BETWEEN $waktu AND b.jenis_pengadilan=4
			GROUP BY satker_id) AS xx ON zz.id=xx.satker_id
			LEFT JOIN 
			(
			SELECT satker_id
			,COUNT(DISTINCT(nomor_perkara))  AS litigasi 
			FROM efiling_berkas_persidangan AS a 
			LEFT JOIN efiling_berkas AS b USING(efiling_id)
			LEFT JOIN efiling AS c USING (efiling_id)
			LEFT JOIN pengadilan_negeri AS d
				ON c.satker_id=d.id
			WHERE d.jenis_pengadilan=4
				AND tgl_pendaftaran_perkara BETWEEN $waktu
				AND doc_id=7
			GROUP BY satker_id
			) AS yy USING(satker_id)
			
			WHERE zz.jenis_pengadilan=4 $s_ec
			"; 
			*/
			$query		= "
			SELECT zz.id,nama,ecourt,ecourt as litigasi
			FROM
			pengadilan_negeri AS zz LEFT JOIN
			(SELECT satker_id,COUNT(satker_id) AS ecourt
			FROM efiling a
			LEFT JOIN pengadilan_negeri b
			ON a.satker_id=b.id
			WHERE tgl_pendaftaran_perkara BETWEEN $waktu AND b.jenis_pengadilan=4
			GROUP BY satker_id) AS xx ON zz.id=xx.satker_id
			
			
			WHERE zz.jenis_pengadilan=4 $s_ec
			"; 
			//die($query);
			$mysql_query= mysqli_query($kon_ec, $query);
			while($record = mysqli_fetch_assoc ($mysql_query))
			{
				$hasil[] = $record; 
			}
			$jadi=array();
			foreach($hasil as $key=>$value) {
				$idsat=$value['id'];
				$jadi[$idsat]['id_satker']=$value['id'];
				$jadi[$idsat]['nama_satker']=$value['nama'];
				$jadi[$idsat]['ecourt']=$value['ecourt'];
				$jadi[$idsat]['litigasi']=$value['litigasi'];
			}
			

			$server	= "192.168.99.161";
			$username	= "rekap";
			$password	= "badilagjaya";
			$database	= "pusat_data";
			$kon_sip = mysqli_connect("$server","$username","$password","$database");
			
			$print2		= "
			SELECT  yy.id AS id_satker,xx.jml
			FROM pengadilan_negeri AS yy LEFT JOIN
			(SELECT id_satker,COUNT(id_satker) AS jml
			FROM data_perkara 
			WHERE tgl_daftar BETWEEN $waktu
			GROUP BY id_satker) AS xx ON yy.id=xx.id_satker $s_sip
			
			";

			$exe_print= mysqli_query($kon_sip, $print2);
			
			while($isi = mysqli_fetch_assoc ($exe_print))
			{
				$hs_sip[] = $isi; 
			}
			
			foreach($hs_sip as $key=>$value) {
				$idsat=$value['id_satker'];
				$jadi[$idsat]['perdata']=$value['jml'];
				if(empty($value['jml'])) {$value['jml']=0;}
				
				
				
				if($value['jml']==0) 
					{$jadi[$idsat]['persentase']=0;
						}
					else{
						$pro1=$jadi[$idsat]['ecourt']/$value['jml']*50;
						if(empty($jadi[$idsat]['litigasi'])) 
							{$pro2=0;}
							else{$pro2=$jadi[$idsat]['litigasi']/$jadi[$idsat]['ecourt']*50;}
						
						
						$jadi[$idsat]['persentase']=$pro1+$pro2;
						}
				
			}
			
				if(!mysqli_num_rows($mysql_query)) 
				{ 
				echo "Load Data Api Gagal.... !!!";
				}
				else
				{
				
				foreach($jadi as $key=>$value) {
				$jk[]=$value;
				}
				echo JSON_ENCODE($jk);
				}
	
	
?>