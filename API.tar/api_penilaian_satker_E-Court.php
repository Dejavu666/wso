<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "HAVING id_satker='$id_satker'";
	
	// die($tahun);
					
	// $query		= "
					// SELECT 
						// X.satker_id AS id_satker,X.nama AS nama_satker,IFNULL(X.ecourt,0) AS ecourt,IFNULL(X.perdata,0) AS perdata,
						// IFNULL(ROUND(X.ecourt/X.perdata*100,3),0) AS persentase
						// FROM 
							// (
								// SELECT A.satker_id, A.nama, 
								// (
									// SELECT SUM(masuk) FROM tb_perkara_rekap_ecourt
									// WHERE tahun=A.tahun 
										// AND satker_id=A.satker_id
										// AND bulan BETWEEN 1 AND 3
								// )  AS ecourt,
								// SUM(A.masuk) AS perdata
								// FROM tb_perkara_rekap_pertama AS A
								// WHERE A.tahun='$tahun'
								// GROUP BY A.satker_id
								// ORDER BY A.satker_id
							// ) AS X"; 
							
	$query		= "
					SELECT A.id_satker,A.nama_satker,A.jumlah_perk_perdata AS perdata,A.jumlah_perk_ecourt AS ecourt,A.jumlah_perk_elitigasi AS litigasi,
						ROUND((A.jumlah_perk_ecourt / A.jumlah_perk_perdata * 50) + (A.jumlah_perk_elitigasi / A.jumlah_perk_ecourt * 50),2) AS persentase
					FROM triwulan_ecourt AS A 
						WHERE A.tahun_laporan='$tahun' AND A.id_triwulan='$triwulan'
					$SATKER
				  ";
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
		
	 
?>