<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	// die($tahun);
	
	$query		= "SELECT X.id_satker,X.nama_satker,Y.nama_juara,Y.persentase 
					FROM penilaian_satker.master_satker AS X 
					LEFT JOIN
						(
							SELECT O.id_satker, 
							NAMA_SATKER(O.id_satker) AS nama_satker,
							GROUP_CONCAT(CONCAT(O.nama_juara,': Nilai ',O.nilai) SEPARATOR '<br>') AS nama_juara,
							ROUND(AVG(O.nilai),2) AS persentase
							FROM (
							SELECT A.id_satker, NAMA_SATKER(A.id_satker) AS nama_satker,A.nama_juara,
							IF(A.peringkat='1',100,
								IF(A.peringkat='2',80,
									IF(A.peringkat='3',60,
										40
							))) AS nilai
							FROM tb_juara AS A 
							WHERE ($tahun - A.tahun_juara <= 3) AND A.peringkat IN (1,2,3,4)
							) AS O
							GROUP BY O.id_satker
						) AS Y ON X.id_satker_dipa01=Y.id_satker
					WHERE X.aktif='1' AND X.tingkat_satker='PA'
					ORDER BY X.id_satker ASC
				"; 
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$record['nama_juara'] =  preg_replace('/[^A-Za-z0-9\ ]/','',$record['nama_juara']); // buat karakter aneh di buang, banyak banget di db komar
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
		
	 
?>