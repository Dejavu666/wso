<?php
	// IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	$query		= " 
					SELECT X.*, ROUND((X.jumlah_validasi/X.total_validasi)*100, 2) AS persentase
					FROM 
						(
							SELECT 
								A.id AS id_satker, 
								A.nama AS nama_satker, 
								B.jml_validasi AS jumlah_validasi,
								(SELECT jml_hari_aktiv FROM triwulan_ms_jml_harikerja WHERE tahun=B.tahun AND triwulan=B.triwulan) AS total_validasi
							FROM pengadilan_negeri AS A 
								LEFT JOIN triwulan_val_keuangan AS B ON B.id_satker=A.id AND B.tahun = '$tahun' AND B.triwulan='$triwulan'
						) AS X
				 "; 			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>