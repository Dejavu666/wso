<?php
	// IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	$url_api = 'https://api.badilag.net/sipweb/';
	$ch = curl_init($url_api);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$page = curl_exec($ch);
	curl_close($ch);
	$array 	= JSON_DECODE($page, TRUE);		
	$hasil = array();
	// echo "<pre>";
	// print_r($array['data']);die();
	
	// $query		= "SELECT * FROM master_satker AS A WHERE A.`aktif` = '1'";
	$query		= "SELECT A.*, par.nama_satker as nama_satker_parent FROM master_satker AS A LEFT JOIN master_satker as par ON A.id_parent = par.id_satker WHERE A.`aktif` = '1'";
	$mysql_query= mysqli_query($koneksi, $query);
	$satker = array();
	while($record = mysqli_fetch_assoc ($mysql_query))
	{
		$id_dipa01 = $record['id_satker_dipa01'];
		$satker[$id_dipa01] = $record; 
	}
	foreach($array['data'] as $R){
		$row = array();
		$row['id_satker'] 	= $id_satker = $R['kode'];
		$row['nama_satker'] 	= $satker[$id_satker]['nm_satker'];
		$row['nama_satker_parent'] 	= $satker[$id_satker]['nama_satker_parent'];
		$row['nilai']			= $R['poin'];
		$row['persentase']	= $R['persentase'];
		$hasil[] = $row;
		
	}
	
	// echo "<pre>";
	// print_r($hasil);die();
	
	$no = 1;
		echo "<table border ='1'>";
		echo "<tr>
			<td>NO</td>			
			<td>KD SATKER</td>			
			<td>SATKER</td>			
			<td>WILAYAH</td>			
			<td>Total Nilai</td>									
			<td>Persentase</td>									
			</tr>";
			
	foreach($hasil as $R){
		echo "<tr>";
		echo "<td>".$no."</td>";
		echo "<td>".$R['id_satker']."</td>";
		echo "<td>".$R['nama_satker']."</td>";
		echo "<td>".$R['nama_satker_parent']."</td>";
		echo "<td>".$R['nilai']."</td>";
		echo "<td>".$R['persentase']."</td>";
		echo "</tr>";
		$no++;
	};
	
	// echo JSON_ENCODE($hasil);
	// die();
	
?>