<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "HAVING id_satker='$id_satker'";
	
	$query		= "
					SELECT 
						X.*,
						IF(X.persen < 1,0,
							IF(X.persen >= 1 AND X.persen <= 20,50,
								IF(X.persen >= 21 AND X.persen <= 40,75,
									IF(X.persen >= 41,100,
										0
									)
								)
							)
						) AS persentase
					FROM 
						(
							SELECT 
							A.id AS id_satker, 
							A.nama AS nama_satker, 
							B.jumlah_ct_mandiri AS jumlah_ct,
							B.jumlah_cg_mandiri AS jumlah_cg,
							B.jumlah_dispensasi_mandiri AS jumlah_dk,
							(B.jumlah_ct_mandiri+B.jumlah_cg_mandiri+B.jumlah_dispensasi_mandiri) AS jumlah_gm,
							(B.jumlah_ct_sipp+B.jumlah_cg_sipp+B.jumlah_dispensasi_sipp) AS jumlah_sipp,
							IF((ROUND(((B.jumlah_ct_mandiri+B.jumlah_cg_mandiri+B.jumlah_dispensasi_mandiri) / (B.jumlah_ct_sipp+B.jumlah_cg_sipp+B.jumlah_dispensasi_sipp)), 2)*100)>100,100,
								ROUND(((B.jumlah_ct_mandiri+B.jumlah_cg_mandiri+B.jumlah_dispensasi_mandiri) / (B.jumlah_ct_sipp+B.jumlah_cg_sipp+B.jumlah_dispensasi_sipp)), 2)*100) AS persen
							FROM pengadilan_negeri AS A 
							LEFT JOIN triwulan_gugatan_mandiri AS B ON B.id_satker=A.kode AND B.tahun ='$tahun' AND B.triwulan='$triwulan'
							$SATKER
						) AS X
				 "; 			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>