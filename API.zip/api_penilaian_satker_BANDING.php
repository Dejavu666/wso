<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "HAVING id_satker='$id_satker'";
	
	IF($triwulan == 1) 
		{
			$tgl_awal 	= "$tahun-01-01"; 
			$tgl_akhir 	= "$tahun-03-31"; 
		}
		
	IF($triwulan == 2) 
		{
			$tgl_awal 	= "$tahun-04-01"; 
			$tgl_akhir 	= "$tahun-06-31"; 
		}
		
	IF($triwulan == 3) 
		{
			$tgl_awal 	= "$tahun-07-01"; 
			$tgl_akhir 	= "$tahun-09-31"; 
		}
		
	IF($triwulan == 4) 
		{
			$tgl_awal 	= "$tahun-10-01"; 
			$tgl_akhir 	= "$tahun-12-31"; 
		}
		
	$query		= "
					SELECT AAA.id_satker_sipp AS id_satker,AAA.nama_satker,
						IFNULL(AAA.jumlah_putus,0) AS jumlah_putus,
						IFNULL(AAA.jumlah_banding,0) AS jumlah_banding,
						IFNULL(AAA.pengiriman,0) AS pengiriman,
						IFNULL(AAA.kelengkapan,0) AS kelengkapan,
						IFNULL(AAA.nilai_maksimal,0) AS nilai_maksimal,
						IFNULL(ROUND(AAA.pengiriman / AAA.nilai_maksimal * 25, 2),0) AS nilai_aspek1,
						IFNULL(ROUND(AAA.kelengkapan / AAA.nilai_maksimal * 25, 2),0) AS nilai_aspek2,
						IFNULL(ROUND((AAA.jumlah_putus - AAA.jumlah_banding) / AAA.jumlah_putus * 50, 2),0) AS nilai_aspek3,
						ROUND(IFNULL((IFNULL((AAA.pengiriman / AAA.nilai_maksimal * 25),0) + IFNULL((AAA.kelengkapan / AAA.nilai_maksimal * 25),0) + IFNULL((AAA.jumlah_putus - AAA.jumlah_banding) / AAA.jumlah_putus * 50, 0)),0),2) AS persentase
					FROM (
						SELECT AA.id_satker_sipp, AA.nama_satker,
							(SELECT IFNULL(SUM(putus+cabut),0) FROM tmp_rekap_periodik_tw1 WHERE satker_id=AA.id_satker_dipa01) AS jumlah_putus,
							(SELECT IFNULL(COUNT(perkara_id),0) FROM tb_perkara_rekap_banding_detail WHERE pn_id=AA.id_satker_sipp AND tanggal_pendaftaran_banding BETWEEN '$tgl_awal' AND '$tgl_akhir') AS jumlah_banding,
							IFNULL(SUM(IF(BB.selisih IS NULL,0,
								IF(BB.selisih >= 0 AND BB.selisih <= 30,5,
									IF(BB.selisih >= 31 AND BB.selisih <= 40,4,
										IF(BB.selisih >= 41 AND BB.selisih <= 50,3,
											IF(BB.selisih >= 51 AND BB.selisih <= 60,2,
												IF(BB.selisih >= 61 AND BB.selisih <= 70,1,
													IF(BB.selisih >= 71 AND BB.selisih <= 80,-1,
														IF(BB.selisih >= 81 AND BB.selisih <= 90,-2,
															IF(BB.selisih >= 91 AND BB.selisih <= 100,-3,
																-4
							)))))))))),0) AS pengiriman,
							
							IFNULL(SUM(IF(BB.is_kelengkapan IS NULL,0,
								IF(BB.is_kelengkapan = 0,5,
									IF(BB.is_kelengkapan = 1,4,
										IF(BB.is_kelengkapan = 2 AND BB.lama_hari <= 30,3,
											IF(BB.is_kelengkapan = 2 AND BB.lama_hari >= 31 AND BB.lama_hari <= 60,2,
												IF(BB.is_kelengkapan = 2 AND BB.lama_hari >= 61 AND BB.lama_hari <= 90,1,
													0
							))))))),0) AS kelengkapan,
							IFNULL(COUNT(BB.id_satker_sipp) * 5, 0) AS nilai_maksimal
						FROM master_satker AS AA
						LEFT JOIN
						(
							SELECT A.pn_id AS id_satker_sipp, B.permohonan_banding, B.tanggal_pendaftaran_banding, B.pengiriman_berkas_banding, DATEDIFF(B.pengiriman_berkas_banding,B.permohonan_banding) AS selisih, A.is_kelengkapan, A.lama_hari
							FROM triwulan_banding_v2 AS A 
							INNER JOIN tb_perkara_rekap_banding_detail AS B ON A.pt_id=B.pt_id AND A.perkara_id=B.perkara_id AND B.tanggal_pendaftaran_banding BETWEEN '$tgl_awal' AND '$tgl_akhir' 
						) AS BB ON AA.id_satker_sipp = BB.id_satker_sipp
						WHERE AA.aktif='1' AND AA.tingkat_satker = 'PA'
						GROUP BY AA.id_satker_sipp
					) AS AAA
					$SATKER
					ORDER BY persentase DESC
				 "; 			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>