<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	// die($tahun);
					
	$query 		= "SELECT 
					Y.id_satker,Y.nama_satker,
					Y.kp_nilai5,Y.kp_nilai3,Y.kp_nilai2,Y.kp_nilai1,Y.kp_nilai0,
					Y.kp_nilai_min1,Y.kp_nilai_min2,Y.kp_nilai_min3,Y.kp_nilai_min4,
					Y.lengkap_nilai5,Y.lengkap_nilai4,Y.lengkap_nilai3,Y.lengkap_nilai2,Y.lengkap_nilai1,Y.lengkap_nilai0,	
					ROUND(IFNULL(((Y.kp_nilai5+Y.kp_nilai3+Y.kp_nilai2+Y.kp_nilai1+Y.kp_nilai0+Y.kp_nilai_min1+Y.kp_nilai_min2+Y.kp_nilai_min3+Y.kp_nilai_min4) / Y.jumlah_kp * 0.5),0),2) AS persentase_kp,
					ROUND(IFNULL(((Y.lengkap_nilai5+Y.lengkap_nilai4+Y.lengkap_nilai3+Y.lengkap_nilai2+Y.lengkap_nilai1+Y.lengkap_nilai0) / Y.jumlah_lengkap * 0.5),0),2) AS persentase_lengkap,
					ROUND(IFNULL(((Y.kp_nilai5+Y.kp_nilai3+Y.kp_nilai2+Y.kp_nilai1+Y.kp_nilai0+Y.kp_nilai_min1+Y.kp_nilai_min2+Y.kp_nilai_min3+Y.kp_nilai_min4) / Y.jumlah_kp * 0.5),0) + IFNULL(((Y.lengkap_nilai5+Y.lengkap_nilai4+Y.lengkap_nilai3+Y.lengkap_nilai2+Y.lengkap_nilai1+Y.lengkap_nilai0) / Y.jumlah_lengkap * 0.5),0),2) AS persentase
					FROM 
						(
							SELECT 
							X.id_satker,X.nama_satker,
							(X.kp_nilai5 * 5) AS kp_nilai5,
							(X.kp_nilai3 * 3) AS kp_nilai3,
							(X.kp_nilai2 * 2) AS kp_nilai2,
							(X.kp_nilai1 * 1) AS kp_nilai1,
							(X.kp_nilai0 * 0) AS kp_nilai0,
							(X.kp_nilai_min1 * -1) AS kp_nilai_min1,
							(X.kp_nilai_min2 * -2) AS kp_nilai_min2,
							(X.kp_nilai_min3 * -3) AS kp_nilai_min3,
							(X.kp_nilai_min4 * -4) AS kp_nilai_min4,
							(X.lengkap_nilai5 * 5) AS lengkap_nilai5,
							(X.lengkap_nilai4 * 4) AS lengkap_nilai4,
							(X.lengkap_nilai3 * 3) AS lengkap_nilai3,
							(X.lengkap_nilai2 * 2) AS lengkap_nilai2,
							(X.lengkap_nilai1 * 1) AS lengkap_nilai1,
							(X.lengkap_nilai0 * 0) AS lengkap_nilai0,
							X.jumlah_kp,X.jumlah_lengkap
							FROM 
								(
									SELECT A.id_satker,penilaian_satker.NAMA_SATKER(A.id_satker) AS nama_satker,
										B.kp_nilai5,B.kp_nilai3,B.kp_nilai2,B.kp_nilai1,B.kp_nilai0,
										B.kp_nilai_min1,B.kp_nilai_min2,B.kp_nilai_min3,B.kp_nilai_min4,
										B.lengkap_nilai5,B.lengkap_nilai4,B.lengkap_nilai3,B.lengkap_nilai2,B.lengkap_nilai1,B.lengkap_nilai0,
										IFNULL((B.kp_nilai5+B.kp_nilai3+B.kp_nilai2+B.kp_nilai1+B.kp_nilai0+B.kp_nilai_min1+B.kp_nilai_min2+B.kp_nilai_min3+B.kp_nilai_min4),0) AS jumlah_kp,
										IFNULL((B.lengkap_nilai5+B.lengkap_nilai4+B.lengkap_nilai3+B.lengkap_nilai2+B.lengkap_nilai1+B.lengkap_nilai0),0) AS jumlah_lengkap
									FROM penilaian_satker.master_satker AS A
									INNER JOIN triwulan_kasasi_pk AS B ON A.id_satker_dipa01=B.id_satker AND B.id_triwulan='$triwulan' AND B.tahun_laporan='$tahun' 
									WHERE A.aktif='1' AND A.tingkat_satker='PA'
								) AS X 
						) AS Y";
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
		
	 
?>