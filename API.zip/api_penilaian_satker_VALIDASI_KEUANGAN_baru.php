<?php

REQUIRE_ONCE "./@@api_function.php";
	

$server		= "192.168.99.159";
$username	= "kinsatker";
$password	= "Badilagjaya";
$database	= "monitoring_aps_bck";


$koneksi_keu = mysqli_connect("$server","$username","$password","$database");

	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']); 
	$th_next=$tahun+1;
	
	// $tahun=2023;
	// $triwulan=2;
	// $th_next=$tahun+1;
	
	if($triwulan==1) { $waktu="'$tahun-01-01' AND '$tahun-03-31'"; 
						$waktu2=" AND waktu_kirim<='$tahun-04-07'";}
	elseif($triwulan==2){ $waktu="'$tahun-04-01' AND '$tahun-06-30'"; 
							$waktu2=" AND waktu_kirim<='$tahun-07-07'";}
	elseif($triwulan==3){$waktu="'$tahun-07-01' AND '$tahun-09-30'"; 
							$waktu2=" AND waktu_kirim<='$tahun-10-07'"; }
	elseif($triwulan==4){$waktu="'$tahun-10-01' AND '$tahun-12-31'"; 
							$waktu2=" AND waktu_kirim<='$th_next-01-07'";}
	else{$waktu="";}
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "AND a.id_satker_sipp='$id_satker'";
	$query		= "
	SELECT a.id_satker_sipp AS id_satker,a.nm_satker AS nama_satker,IF(jml_kirim IS NULL,0,jml_kirim) AS jumlah_validasi,
				(SELECT COUNT(tanggal) FROM ref_hari_kerja WHERE tanggal BETWEEN $waktu) AS total_validasi,
				FORMAT((IF(jml_kirim IS NULL,0,jml_kirim)/
				(SELECT COUNT(tanggal) FROM ref_hari_kerja WHERE tanggal BETWEEN $waktu)*100),0) AS persentase
				
				FROM master_satker a LEFT JOIN
				
				(SELECT id_satker,COUNT(tanggal_transaksi) AS jml_kirim
				FROM validasi_harian_log  
				JOIN ref_hari_kerja  ON tanggal_transaksi=tanggal 
				WHERE tanggal_transaksi BETWEEN $waktu $waktu2
				GROUP BY id_satker) b ON a.`id_satker_sipp`=b.id_satker
				LEFT JOIN master_satker c ON a.`id_parent`=c.`id_satker`
				
				WHERE a.tingkat_satker='PA' AND a.id_satker_dipa01 IS NOT NULL $SATKER
				ORDER BY a.urutan";
	
	
		
	//die($query);
	$mysql_query= mysqli_query($koneksi_keu, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		} 
?>