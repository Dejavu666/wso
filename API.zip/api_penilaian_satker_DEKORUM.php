<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "HAVING id_satker='$id_satker'";
	
	// die($tahun);
	$query		= "
					SELECT X.*,
						ROUND(X.jumlah_point / X.jumlah_ruang_sidang / 27 * 100, 2) AS persentase
						FROM ( 
						SELECT A.id AS id_satker,  A.nama AS nama_satker, 
						COUNT(B.ruang_sidangke) AS jumlah_ruang_sidang,
							SUM(B.is_beludru_hakim) AS beludru_hakim,
							SUM(B.is_meja_hakim) AS meja_hakim,
							SUM(B.is_beludru_pp) AS beludru_pp,
							SUM(B.is_meja_pp) AS meja_pp,
							SUM(B.is_beludru_pihak) AS beludru_pihak,
							SUM(B.is_meja_pihak) AS meja_pihak,
							SUM(B.is_kursi_hadap) AS kursi_hadap,
							SUM(B.is_posisi_kursi_p) AS posisi_kursi_p,
							SUM(B.is_posisi_kursi_t) AS posisi_kursi_t,
							SUM(B.is_posisi_kursi_dakwa) AS kursi_dakwa,
							SUM(B.is_sekat) AS sekat,
							SUM(B.is_bangku) AS bangku,
							SUM(B.is_palusidang) AS palusidang,
							SUM(B.is_bendaraputih) AS bendaraputih,
							SUM(B.is_garuda) AS garuda,
							SUM(B.is_kalender) AS kalender,
							SUM(B.is_jamdinding) AS jamdinding,
							SUM(B.is_sounds) AS SOUNDS,
							SUM(B.is_alquran) AS alquran,
							SUM(B.is_komputer) AS komputer,
							SUM(B.is_mediator) AS mediator,
							SUM(B.is_pendingin) AS pendingin,
							SUM(B.is_cctv) AS cctv,
							SUM(B.is_apar) AS apar,
							SUM(B.is_alarm) AS alarm,
							SUM(B.is_teleconference) AS teleconference,
							SUM(B.is_detektor) AS detektor,
							(
								SUM(B.is_beludru_hakim) + 
								SUM(B.is_meja_hakim) + 
								SUM(B.is_beludru_pp) + 
								SUM(B.is_meja_pp) + 
								SUM(B.is_beludru_pihak) +
								SUM(B.is_meja_pihak) +
								SUM(B.is_kursi_hadap) + 
								SUM(B.is_posisi_kursi_p) + 
								SUM(B.is_posisi_kursi_t) + 
								SUM(B.is_posisi_kursi_dakwa) + 
								SUM(B.is_sekat) + 
								SUM(B.is_bangku) + 
								SUM(B.is_palusidang) + 
								SUM(B.is_bendaraputih) + 
								SUM(B.is_garuda) + 
								SUM(B.is_kalender) + 
								SUM(B.is_jamdinding) + 
								SUM(B.is_sounds) + 
								SUM(B.is_alquran) + 
								SUM(B.is_komputer) + 
								SUM(B.is_mediator) + 
								SUM(B.is_pendingin) + 
								SUM(B.is_cctv) + 
								SUM(B.is_apar) + 
								SUM(B.is_alarm) + 
								SUM(B.is_teleconference) + 
								SUM(B.is_detektor) 
							) AS jumlah_point
						FROM pengadilan_negeri AS A 
							LEFT JOIN triwulan_dekorum AS B ON B.id_satker=A.kode AND B.tahun_laporan = '$tahun' AND B.id_triwulan='$triwulan'
						GROUP BY A.id
						) AS X
					$SATKER
				 "; //27 = jumlah field			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>