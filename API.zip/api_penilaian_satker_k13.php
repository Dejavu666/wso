<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	// die($tahun);
	
	$query		= "
					SELECT X.id_satker,X.nama_satker,Y.predikat AS akreditasi,
						IF(Y.predikat='A',100,
							IF(Y.predikat='B',80,
								IF(Y.predikat='C',60,
								0)
							)
						) AS persentase 
					FROM penilaian_satker.master_satker AS X 
					LEFT JOIN 
						(
							SELECT A.*, NAMA_SATKER(A.id_satker) AS nama_satker
							FROM triwulan_apm AS A 
							WHERE A.tahun = '$tahun'
						) AS Y ON X.id_satker_dipa01=Y.id_satker AND Y.id_triwulan='$triwulan'
					WHERE X.aktif='1' AND X.tingkat_satker='PA'
					"; 
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>