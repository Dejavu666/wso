<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	// die($tahun);
	
	// $query		= "
					// SELECT X.id_satker,X.nama_satker,Y.predikat AS akreditasi,
						// IF(Y.predikat='A',100,
							// IF(Y.predikat='B',80,
								// IF(Y.predikat='C',60,
								// 0)
							// )
						// ) AS persentase 
					// FROM penilaian_satker.master_satker AS X 
					// LEFT JOIN 
						// (
							// SELECT A.*, NAMA_SATKER(A.id_satker) AS nama_satker
							// FROM triwulan_apm AS A 
							// WHERE A.tahun = '$tahun'
						// ) AS Y ON X.id_satker_sipp=Y.id_satker
					// WHERE X.aktif='1' AND X.tingkat_satker='PA'
				 // "; 		
	$query		= "
					SELECT 
						penilaian_satker.ID_SATKER_DIPA01(Y.id_satker) AS id_satker, 
						penilaian_satker.NAMA_SATKER(penilaian_satker.ID_SATKER_DIPA01(Y.id_satker)) AS nama_satker,
						Y.lokasi_ptsp,Y.desain_ptsp,Y.tulisan_ptsp,
						Y.meja_panjang,Y.kursi,Y.komputer_laptop,Y.printer,Y.telepon,Y.alat_tulis,Y.buku_register,Y.brosur_ptsp,Y.papan_nama_petugas,Y.papan_istrihat,
						Y.mesin_antrian,Y.media_center,Y.cctv_ptsp,
						Y.layanan_informasi,Y.layanan_pendaftaran,Y.layanan_pembayaran,Y.layanan_ambil_produk,Y.layanan_pengaduan,
						Y.layanan_bank,Y.layanan_posbakum,Y.layanan_pos,
						Y.waktu_operasional,Y.prosedur_layanan,
						Y.cakap_ptsp,Y.ramah_ptsp,Y.rapih_ptsp,
						(
							(
								Y.lokasi_ptsp+Y.desain_ptsp+Y.tulisan_ptsp+
								Y.meja_panjang+Y.kursi+Y.komputer_laptop+Y.printer+Y.telepon+Y.alat_tulis+Y.buku_register+Y.brosur_ptsp+Y.papan_nama_petugas+Y.papan_istrihat+
								Y.mesin_antrian+Y.media_center+Y.cctv_ptsp+
								Y.layanan_informasi+Y.layanan_pendaftaran+Y.layanan_pembayaran+Y.layanan_ambil_produk+Y.layanan_pengaduan+
								Y.layanan_bank+Y.layanan_posbakum+Y.layanan_pos+
								Y.waktu_operasional+Y.prosedur_layanan+
								Y.cakap_ptsp+Y.ramah_ptsp+Y.rapih_ptsp
							) / 29 * 10
						) AS persentase 
					FROM 
							(
								SELECT A.*
								FROM triwulan_ptsp AS A 
									INNER JOIN pengadilan_negeri AS B ON A.id_satker=B.kode
								WHERE A.tahun_laporan = '$tahun' AND A.id_triwulan='$triwulan'
							) AS Y 
				 "; 			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>