<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	// $tahun		= '2022';
	// $triwulan	= '2';
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = " AND A.id_satker='$id_satker'";
	$query		= "
					SELECT A.`id_satker`,
					A.nama_satker,
					SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '1' THEN 1 else 0 END) as inovasi_baru,
					SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0' THEN 1 ELSE 0 END) as inovasi_lama,
					SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0'  AND VER.keberlanjutan_inovasi = '1' THEN 1 ELSE 0 END) as inovasi_lama_berlanjut,

					CASE WHEN SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '1' THEN 1 else 0 END) > 0 THEN 50 ELSE 0 END AS kriteria_1,

					CASE 
					WHEN (SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0'  AND VER.keberlanjutan_inovasi = '1' THEN 1 ELSE 0 END)
					/SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0' THEN 1 ELSE 0 END)) > 0.5 THEN 50 
					WHEN (SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0'  AND VER.keberlanjutan_inovasi = '1' THEN 1 ELSE 0 END)
					/SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0' THEN 1 ELSE 0 END)) > 0 THEN 25 
					ELSE 0 END AS kriteria_2,

					(CASE WHEN SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '1' THEN 1 else 0 END) > 0 THEN 50 ELSE 0 END
					+
					CASE 
					WHEN (SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0'  AND VER.keberlanjutan_inovasi = '1' THEN 1 ELSE 0 END)
					/SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0' THEN 1 ELSE 0 END)) > 0.5 THEN 50 
					WHEN (SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0'  AND VER.keberlanjutan_inovasi = '1' THEN 1 ELSE 0 END)
					/SUM(CASE WHEN INO.`id_triwulan` = '$triwulan' AND INO.`tahun_laporan` ='$tahun' AND VER.status_inovasi = '0' THEN 1 ELSE 0 END)) > 0 THEN 25 
					ELSE 0 END) as persentase


					FROM master_satker AS A 
					LEFT JOIN tb_inovasi AS INO ON A.`id_satker_dipa01` = INO.`id_satker`
					LEFT JOIN tb_inovasi_verifikasi AS VER ON INO.`id_inovasi` = VER.`id_inovasi`
					WHERE A.tingkat_satker IN('PA') AND A.aktif = TRUE
					$SATKER
					GROUP BY A.`id_satker`

					;
				 "; 			
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>