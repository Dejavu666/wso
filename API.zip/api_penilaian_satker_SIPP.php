<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);

	$bulan_akhir= $triwulan * 3;
	$bulan_awal	= $bulan_akhir - 2;
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "AND pn_id='$id_satker'";
	
	$query		= "SELECT DISTINCT A.tanggal_penilaian, 
						(SELECT  COUNT(DISTINCT tanggal_penilaian) FROM rekap_sipp_mingguan WHERE tanggal_penilaian <= A.tanggal_penilaian AND YEAR(tanggal_penilaian) = YEAR(A.tanggal_penilaian)) AS minggu_ke  
					FROM rekap_sipp_mingguan AS A
					WHERE YEAR(A.tanggal_penilaian) = '$tahun' AND MONTH(A.tanggal_penilaian) BETWEEN $bulan_awal AND $bulan_akhir $SATKER
					ORDER BY A.tanggal_penilaian ASC 
				  ";
	// die($query."fff");
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Tidak Ada Tanggal Penilaian Pada Triwulan ini... !!!";
		}
	else
		{
			
			$field = "";
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					// $field .= "SUM(IF(tanggal_penilaian='$record[tanggal_penilaian]' AND nilai>0,nilai,NULL)) AS 'minggu$record[minggu_ke]'"; 
					$field .= "'^',ROUND(SUM(IF(tanggal_penilaian='$record[tanggal_penilaian]' AND nilai>0,nilai,0)),2),"; 
					// IF($record['minggu_ke']<mysqli_num_rows($mysql_query)) $field .= ",";
				}
			$field = SUBSTR($field,0,-1);
			// echo $field;
			
			$query	= "
						SELECT pn_id AS id_satker, nama_satker, 
						CONCAT($field) AS perincian_nilai
						FROM rekap_sipp_mingguan
						WHERE YEAR(tanggal_penilaian)='$tahun' AND MONTH(tanggal_penilaian) BETWEEN $bulan_awal AND $bulan_akhir $SATKER
						GROUP BY pn_id ASC;
					  "; 
			// die($query);
			$mysql_query= mysqli_query($koneksi, $query);
			if(!mysqli_num_rows($mysql_query)) 
				{ 
					echo "Load Data Api Gagal... !!!";
				}
			else
				{
					while($record = mysqli_fetch_assoc ($mysql_query))
						{
							$hasil[] = $record; 
						}
					echo JSON_ENCODE($hasil);
				}
		}
?>