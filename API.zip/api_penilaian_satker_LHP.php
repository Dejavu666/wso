<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	$id_satker	= DEC($_POST['id_satker']);
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "HAVING id_satker='$id_satker'";
	
	IF($triwulan == 1) 
		{
			$in_bulan 	= "1,2,3"; 
		}
		
	IF($triwulan == 2) 
		{
			$in_bulan 	= "4,5,6"; 
		}
		
	IF($triwulan == 3) 
		{
			$in_bulan 	= "7,8,9"; 
		}
		
	IF($triwulan == 4) 
		{
			$in_bulan 	= "10,11,12"; 
		}
	
	// backup query tanggal 2022 07 18
	// $query		= "
					// SELECT A2.id_satker, (SELECT nama_satker FROM master_satker WHERE A2.id_satker = id_satker_dipa01) AS nama_satker,
						// CONCAT('!',GROUP_CONCAT(CONCAT('^',A2.bulan,'^',A2.total_temuan,'^',A2.total_tindak_lanjut,'^',A2.nilai_temuan,'^',A2.nilai_tindak_lanjut) SEPARATOR '!')) AS nilai_mentah, 
						// IFNULL(ROUND(SUM(A2.nilai_temuan) / 3,2),0) AS total_nilai_temuan,
						// IFNULL(ROUND(SUM(A2.nilai_tindak_lanjut) / 3,2),0) AS total_nilai_tindak_lanjut,
						// IFNULL(ROUND(SUM(A2.nilai_temuan) / 3,2),0) + IFNULL(ROUND(SUM(A2.nilai_tindak_lanjut) / 3,2),0) AS persentase
					// FROM (
						// SELECT A1.*,
							// 50 AS nilai_temuan,
							// IF(A1.total_tindak_lanjut = A1.total_temuan,50,IF(A1.total_tindak_lanjut != 0 AND A1.total_tindak_lanjut < A1.total_temuan,25,IF(A1.total_tindak_lanjut=0 AND A1.total_temuan > 0,0,NULL))) AS nilai_tindak_lanjut
						// FROM (
							// SELECT A.id, A.id_satker, A.bidang, 
							// MONTH(A.tgl_pengawasan) AS bulan, 
							// SUM(A.jumlah_temuan) AS total_temuan, 
							// SUM(A.jumlah_tindak_lanjut) AS total_tindak_lanjut

							// FROM data_lhp_manual AS A
							// GROUP BY A.id_satker, bulan
							// HAVING bulan IN ($in_bulan)
						// ) AS A1 
					// ORDER BY A1.id_satker ASC, A1.bulan ASC
					// ) AS A2
					// GROUP BY A2.id_satker
					// ;
				 // "; 		
	$query = "SELECT Y.id_satker,
					(SELECT nama_satker FROM master_satker WHERE Y.id_satker = id_satker_dipa01) AS nama_satker,
					Y.total_temuan,
					Y.total_tindak_lanjut,
					Y.nilai_temuan,
					Y.nilai_tindak_lanjut,
					(Y.nilai_temuan + Y.nilai_tindak_lanjut) AS persentase
				FROM 
				(
					SELECT X.*,
						IF(X.total_temuan >= 0, 50, 0) AS nilai_temuan,
						IF(X.total_tindak_lanjut >= X.total_temuan,50,IF(X.total_tindak_lanjut != 0 AND X.total_tindak_lanjut < X.total_temuan,25,IF(X.total_tindak_lanjut=0 AND X.total_temuan > 0,0,NULL))) AS nilai_tindak_lanjut
					FROM (
						SELECT A.id, A.id_satker, 
							SUM(A.jumlah_temuan) AS total_temuan, 
							SUM(A.jumlah_tindak_lanjut) AS total_tindak_lanjut
						FROM data_lhp_manual AS A
						WHERE YEAR(A.tgl_pengawasan) = '$tahun' AND MONTH(A.tgl_pengawasan) IN ($in_bulan)
						GROUP BY A.id_satker
					) AS X
				) AS Y
				GROUP BY Y.id_satker
				$SATKER
				";
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
?>