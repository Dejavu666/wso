<?php
	// IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	REQUIRE_ONCE "./@@api_function.php";
	
	$server2	= "192.168.201.16";
	$username2	= "rekap";
	$password2	= "badilagjaya";
	$database2	= "pusat_data";
	$kon_sip = mysqli_connect("$server2","$username2","$password2","$database2");
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	$id_satker	= DEC($_POST['id_satker']); 
	
	
	$tahun=2023;
	$triwulan=2;
	// $id_satker=0;
	
	$th_next=$tahun+1;
	
	IF(!$id_satker > 0) $SATKER = ""; ELSE $SATKER = "AND id_satker_sipp='$id_satker'";
	
	if($triwulan==1) { $waktu="'$tahun-01-01' AND '$tahun-03-31'"; 
	$waktu2=" AND waktu_kirim<='$tahun-04-07'";}
	elseif($triwulan==2){ $waktu="'$tahun-04-01' AND '$tahun-06-30'"; 
	$waktu2=" AND waktu_kirim<='$tahun-07-07'";}
	elseif($triwulan==3){$waktu="'$tahun-07-01' AND '$tahun-09-30'"; 
	$waktu2=" AND waktu_kirim<='$tahun-10-07'"; }
	elseif($triwulan==4){$waktu="'$tahun-10-01' AND '$tahun-12-31'"; 
	$waktu2=" AND waktu_kirim<='$th_next-01-07'";}
	else{$waktu="";}
	
	
	$query		= "SELECT a.id_satker_sipp as id_satker, a.nm_satker as nama_satker,berhasil_akta_damai,berhasil_cabut,berhasil_sebagian,tidak_berhasil,tidak_dapat_dilaksanakan,total_mediasi,
	(
	ROUND(CASE WHEN ((berhasil_akta_damai+berhasil_cabut+(berhasil_sebagian/2))/total_mediasi*100) IS NULL THEN 0 ELSE
	((berhasil_akta_damai+berhasil_cabut+(berhasil_sebagian/2))/total_mediasi*100) END,2)
	) AS persentase
	FROM master_satker AS a LEFT JOIN
	(SELECT 
	id_satker,
	SUM(CASE WHEN hasil_mediasi='Y1' THEN 1 ELSE 0 END) AS berhasil_akta_damai,
	SUM(CASE WHEN hasil_mediasi='Y2' THEN 1 ELSE 0 END) AS berhasil_cabut,
	SUM(CASE WHEN hasil_mediasi='S' THEN 1 ELSE 0 END) AS berhasil_sebagian,
	SUM(CASE WHEN hasil_mediasi='T' THEN 1 ELSE 0 END) AS tidak_berhasil,
	SUM(CASE WHEN hasil_mediasi='D' THEN 1 ELSE 0 END) AS tidak_dapat_dilaksanakan,
	COUNT(id_satker) AS total_mediasi
	FROM data_mediasi 
	WHERE tgl_keputusan_mediasi BETWEEN $waktu
	GROUP BY id_satker) AS b ON a.`id_satker_sipp`=b.id_satker
	WHERE a.aktif=1 AND tingkat_satker='PA' $SATKER
	"; 
	//die($query);
	$mysql_query= mysqli_query($kon_sip, $query);
	if(!mysqli_num_rows($mysql_query)) 
	{ 
		echo "Load Data Api Gagal... !!!";
	}
	// else
	// {
		// while($record = mysqli_fetch_assoc ($mysql_query))
		// {
			// $hasil[] = $record; 
		// }
		// echo JSON_ENCODE($hasil);
	// }
	else
	{	
		echo "<table><tr>
		<td>id_satker</td>
		<td>nama_satker</td>
		<td>berhasil_akta_damai</td>
		<td>berhasil_cabut</td>
		<td>berhasil_sebagian</td>
		<td>tidak_berhasil</td>
		<td>tidak_dapat_dilaksanakan</td>
		<td>total_mediasi</td>
		<td>persentase</td>
		</tr>";
		while($value = mysqli_fetch_assoc ($mysql_query)) {
			echo "<tr>";
				echo "<td>".$value['id_satker']."</td>";
				echo "<td>".$value['nama_satker']."</td>";
				echo "<td>".$value['berhasil_akta_damai']."</td>";
				echo "<td>".$value['berhasil_cabut']."</td>";
				echo "<td>".$value['berhasil_sebagian']."</td>";
				echo "<td>".$value['tidak_berhasil']."</td>";
				echo "<td>".$value['tidak_dapat_dilaksanakan']."</td>";
				echo "<td>".$value['total_mediasi']."</td>";
				echo "<td>".$value['persentase']."</td>";
			echo "</tr>";
		}
	}
	
	
?>