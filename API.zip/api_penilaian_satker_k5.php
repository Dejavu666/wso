<?php
	IF(!(ISSET($_POST['tahun']) AND ISSET($_POST['triwulan']))) die();
	
	REQUIRE_ONCE "./@@api_function.php";
	REQUIRE_ONCE "./@config.php";
	
	$tahun		= DEC($_POST['tahun']);
	$triwulan	= DEC($_POST['triwulan']);
	
	// die($tahun);
	
	// $query		= "SELECT satker_id AS id_satker,NAMA_SATKER(satker_id) AS nama_satker,berhasil_dgn_akta_damai,berhasil_dgn_pencabutan,berhasil_sebagian, total, 
						// CONCAT(ROUND(IFNULL(((berhasil_dgn_akta_damai+berhasil_dgn_pencabutan+(0.5*berhasil_sebagian))/ total),0),2)*100,'%') AS nilai
					// FROM tb_sipp_mediasi WHERE tahun='$tahun' 
					// ORDER BY id_satker ASC"; 
	$query		= "SELECT A.id_satker,penilaian_satker.NAMA_SATKER(penilaian_satker.ID_SATKER_DIPA01(A.id_satker)) AS nama_satker,
						A.berhasil_akta_damai,A.berhasil_cabut,A.berhasil_sebagian,A.tidak_berhasil,A.tidak_dapat_dilaksanakan,
						A.persentase AS persentase
					FROM triwulan_mediasi AS A 
					WHERE A.tahun_laporan='$tahun' AND A.id_triwulan='$triwulan'"; 
	// die($query);
	$mysql_query= mysqli_query($koneksi, $query);
	if(!mysqli_num_rows($mysql_query)) 
		{ 
			echo "Load Data Api Gagal... !!!";
		}
	else
		{
			while($record = mysqli_fetch_assoc ($mysql_query))
				{
					$hasil[] = $record; 
				}
			echo JSON_ENCODE($hasil);
		}
		
	 
?>